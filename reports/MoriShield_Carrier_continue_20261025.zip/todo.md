# MoriShield Carrier — Continuation TODO

> **Board state at export (2026-10-25):** `MoriShield_Carrier.kicad_pcb` + `.kicad_sch` (KiCad **10.0** format).
> **DRC: 0 errors** (was 1 clearance error) · **ERC: 0 errors** (was 4) · **Schematic parity: 0** · **Unconnected: 15 pairs** (was 32).
> All zones refilled: GND (In1), +5V (In2), /3V3_SENS_SW island + extension (In2), PE pour (B.Cu).
> 138 DRC warnings remain — all cosmetic (78 silk-over-copper, 46 silk-overlap, 6 track-dangling, 5 via-dangling, 2 text-thickness, 1 lib-footprint-mismatch).

This file tells you exactly what is left, why each remaining connection is hard, and how to finish it.

---

## 1. What is already done (do NOT redo)

| Area | Status |
|---|---|
| D6 status LED (schematic + board) | ✅ Anode keeps /LED_STAT_K, cathode → GND. D6.1 net set, connected via In1 GND plane |
| U8.1 (A0) → GND | ✅ Schematic already had it; board pad set to GND + 0.3 mm jumper to U8.2 |
| Stray wire + duplicate +5V flags near D2 TVS | ✅ Deleted; exactly one PWR_FLAG kept as the +5V driver |
| T6/T7 /3V3_SENS_SW for R47/R48 | ✅ Extra In2.Cu zone (priority 3) + vias at (289.55,134) and (289.55,136.75) |
| **PE network — all 13 pads** | ✅ L-shaped PE pour on B.Cu (bottom band y 196.2–205 + right column x 296.4–304), 12 escape vias, A*-routed legs, F.Cu bridges at x=160 (196.5→203.5), x=176 and x=270 (196.5→200.5), B.Cu stitch at x=246.5, bus at y=203.5 |
| T13 /I2C_SW_RST C29.1→U7.3 | ✅ |
| T14 /I2C0_SDA_CH4 R43.1 | ✅ via (273.6,186.6) |
| T16 /I2C0_SDA_CH3 U7.10→ESD10.1 | ✅ |
| T17-part /I2C0_SCL TP8.1→U8.22 | ✅ via (256.4,164.725) + F.Cu stub |
| T22 /+5V_SENS ESD11.4→J13.1 | ✅ |
| T24 /I2C0_SCL_CH0 ESD7.1→J11.3 | ✅ |
| T27 /3V3_C C7.1→R10.1 | ✅ |
| T28 /3V3_C R37.2→C10.1 | ✅ |
| T34 /+5V_SENS ESD11.5→C33.1 | ✅ via (246.95,176) |
| T36/T48 /I2C0_SCL_CH5 →ESD12.3 | ✅ |
| T42 tail /BUZZER_EN via→U8.18 | ✅ (re-routed tight: (257.5,167.5)→(255.85,167.36)) |
| T39a /PWR_EN U8.16 escape via | ✅ via (256.9,170.1) — but the long haul west is still open (pair 8 below) |
| T51 /3V3_C via (177.75,146.75)→C8.1 | ✅ |
| T44 clearance-error track | ✅ deleted (the old (248.03,162.915)→(244.96,165.99) 3V3_C stub) |
| T25, T31, T46, T53 | ✅ were already routed before this session |

## 2. Environment setup on the other laptop

1. Install **KiCad 10.0** (the files are v10 format — v9 will not open them cleanly).
2. Optional but recommended if you will run the python tools: use KiCad's bundled python, e.g. `C:\Program Files\KiCad\10.0\bin\python.exe` (has `pcbnew`; system Python does not). CLI: `C:\Program Files\KiCad\10.0\bin\kicad-cli.exe`.
3. `tools/` contains the wxWidgets-alert auto-dismiss watchdog from the earlier session (KiCad 10 debug builds pop "wxWidgets Debug Alert" dialogs that freeze scripts). Install only if needed: `powershell -ExecutionPolicy Bypass -File tools\wx_alert_guard.ps1` (see header of that file).
4. Keep the project folder path free of spaces if possible (the current one has them; scripts handle it, but it's safer).

## 3. How to check status at any time

```bat
:: DRC (0 errors expected until you finish; unconnected_items = your worklist)
"C:\Program Files\KiCad\10.0\bin\kicad-cli.exe" pcb drc --format json --output drc.json MoriShield_Carrier.kicad_pcb

:: ERC (should stay 0 errors)
"C:\Program Files\KiCad\10.0\bin\kicad-cli.exe" sch erc --format json --output erc.json MoriShield_Carrier.kicad_sch

:: refill all zones (REQUIRED before every DRC, else you get ~180 fake errors)
"C:\Program Files\KiCad\10.0\bin\python.exe" _auto\refill.py
```

Or simply open the board in the KiCad PCB editor, press `B` (refill zones), then `Inspect → Design Rules Checker`.

**The worklist** = the `unconnected_items` array in the DRC JSON. Each entry pairs two items that must touch.

## 4. The 15 remaining connections (the actual work)

> All coordinates are mm, board coordinates as shown in KiCad (y grows downward).
> General rule discovered in this session: **these are not "not-routed-yet" — they are walled in.** Each one needs either an existing track/via moved (GUI push-and-shove) or a longer detour on the other layer. The obstacle inventory in section 5 is your map.

### 4.1 /I2C0_MUX_SC0 — R32.1 (230.5, 181.5) → U7.5 (237.0, 179.025)  *(hardest short route)*
- **Why it's hard:** the direct corridor is sealed by four walls: /I2C0_MUX_SC1 F.Cu vertical (231.25, 161.75→177.25) + its diagonal to (234.325,180.325); /I2C0_MUX_SD0 via (235, 178.25) sitting exactly in the 1 mm corridor between SC1's end and the /SENS_EN B.Cu horizontal (y=179.25, x 194→241.25); a GND track+via at (237,177.075)→(235,177) (U7.2's escape); /I2C0_SCL_CH2 F.Cu (234.625,181.625)→(237,181.625).
- **Fix A (recommended, GUI):** grab the **/I2C0_MUX_SD0 via (235,178.25)** and drag it ~1 mm west/south-west with its tracks (it only connects a short F.Cu stub), which opens the corridor. Then route SC0: R32.1 → east at y≈181.5 is blocked — instead R32.1 → south-east on F.Cu to (240,188) → north at x=240 → via to B.Cu at (240,170.5) → east under the /SENS_EN staircase's north side → via back to F.Cu → U7.5.
- **Fix B:** push-and-shove the /SENS_EN B.Cu horizontal (y=179.25) 0.5 mm south from x=232…238, then route SC0 straight through the opened corridor on B.Cu.
- U7.5's pad west tip is at x=236.1; enter along y=179.025 (gap to U7.4/U7.6 pads is 0.29 mm — a 0.3 mm track fits, nothing wider).

### 4.2 3V3_C — ESD1.5 (218.1375, 132.0) → the B.Cu fragment ending (222.25, 128.75)
- **Why hard:** /I2C0_SDA F.Cu (219.5,130.25)→(217,130.25)→(216.2,131.05) sits right above ESD1.5's only exit; /UART1_LORA_RX B.Cu diagonal (217.25,130.25)→(230,143) blocks the B.Cu east; ESD1's own no-net pins ESD1.4/ESD1.6 fence the pad N/S.
- **Fix (GUI):** push the /I2C0_SDA F.Cu L-track ~0.4 mm north-west (it has slack), then ESD1.5 → north → 45° NE → via at ≈(221.5,127.5) (stay east of the /E22_M0 diagonal (227.5,131.5)→(217.5,121.5) — a via needs to be ≥0.7 mm from it, e.g. (223.5,126.5)) → B.Cu 0.5 mm → the fragment (222.25,128.75)→(222.25,127).

### 4.3 3V3_C — U8.24 (255.0, 163.425) → C30.1 (244.963, 167.5)
- **Why hard:** GND via (247.0375,167.5) + GND track (247.79,164.075)→(249,164.725) sit between them; U8.1's GND pad (249,163.425) blocks the direct lane; C30.2's pad blocks the west approach.
- **Fix (GUI, works):** route **north of the U8 pad row**: U8.24 → (255,162.865) → west at y=162.865 to (246.5,162.865) → 45° to (244.963,164.4) → south into C30.1 (244.963,167.5). The y=162.865 lane is 0.35 mm above U8.1's pad and clear of the GND track. Also delete the leftover 1.51 mm F.Cu stub (244.963,165.987)→(244.963,167.5) (dangling duplicate).

### 4.4 3V3_C — J4.3 (269.5, 118.64) → the 3V3_C net
- **Why hard:** J4's own THT pad row (2.54 mm pitch) walls B.Cu; the existing F.Cu chain J4.3→(269.61,118.75)→(280.75,118.75)→(282,120) dangles east; /I2C0_SCL_CH6 F.Cu diagonal (268.675,180.325)→(293,156) blocks the F.Cu south at y=167; /I2C0_SDA_CH6 B.Cu vertical (294.55,134→156.2) blocks the east.
- **Fix (GUI):** from the chain end (282,120) route F.Cu **west at y≈119.5** (clear — /UART2_MOD_TX F.Cu runs 2.75 mm south at y=122.75) to x≈250, then **south at x≈250** to y≈162.7 (F.Cu is empty there; watch U7's pads at x≤243.9 and the GND track (247.79,164.075)→(249,164.725) — pass 0.5 mm east of it), then into C30.1 (244.963,167.5) / the via (244.963,167.5). This also feeds the whole 3V3_C net.

### 4.5 PE — ESD19.2 tail + ESD18.2 tail (right column)  *(two pairs, one fix)*
- **What happened:** the PE pour's right column was narrowed to x≥296.4 to kill a sliver; two route ends that terminated inside the old sliver got orphaned: ESD19.2's end (295.125,133.125) and ESD18.2's end (295.125,129.125).
- **Fix ESD18.2 (easy):** extend its B.Cu track (295.125,129.125) → (296.8,129.125). Clear at that y.
- **Fix ESD19.2 (medium):** its end (295.125,133.125) is caged by /I2C0_SDA_CH3 B.Cu vertical (295.875,132.625→178.625) + horizontal (290.375→295.625, y=132.375) + /I2C0_SDA_CH6 F.Cu vertical (294.75,128.25→133.8) — no via fits in the 1.1 mm gap. Re-route its **last two segments**: delete (293.875,133.125)→(295.125,133.125) and (293.625,133.375)→(293.875,133.125); instead from (293.625,136.125) go F.Cu east at y=135.75 (the 1 mm corridor between /I2C0_SDA_CH6 F.Cu ending y=133.8 and /I2C0_SCL_CH6 F.Cu at y=136.75) to (296.7,135.75), via, then B.Cu south inside the column (x=296.7, clear of the /3V3_SENS_SW B.Cu vertical at x=298.75) into the pour.
- **J19.1 (298,109.5)** connects automatically once the column pour is fed again (THT barrel + thermal spokes).

### 4.6 /LED_DRV1 — R51.1 (154.75, 149.05) → U8.4 (249.0, 165.375)
- **Why hard:** U8's west pad column is pad-walled (0.65 mm pitch, U8.3 is GND); the planned west via (247,165.375) collides with a GND via (246.81,165.06) + GND track.
- **Fix (GUI):** escape U8.4 **east under the chip body** (F.Cu between the pad columns is empty): U8.4 → (252,165.375), via there (clear — nearest obstacle /SENS_EN F.Cu 1.86 mm), then B.Cu 0.25 mm west-south-west ~95 mm to R51.1 (via (145.5,147.25) + F.Cu stub into R51.1 — R51.1's island already reaches (147.25,147.21)). Use the GUI router with shove; the scripted A* proved the direct lanes full.
- Alternative: raise R51.1's end and route on B.Cu at y≈150–152 (north of the 3V3_C B.Cu (165.31,159)→(143.55,159) bundle), then drop south to U8.4 through the x≈251–252 body corridor.

### 4.7 /LED_DRV2 — via (251.5, 166.0) → R52.1 (153.5, 141.05)
- Same middle-lattice problem as 4.6 (98 mm on B.Cu). R52.1's island already reaches F.Cu (147.25,140.98) — put the arrival via at (145.75,141).
- **Fix (GUI):** B.Cu from (251.5,166) west along y≈166, jogging north over the 3V3_C B.Cu (213,168)→(209.25,168) bundle and the (214.65,164.4→166.35) bits, then to (145.75,141). Shove where needed.

### 4.8 /UART2_MOD_TX — J2.17 (183.5, 113.36) → J4.5 (269.5, 123.72)  *(both THT — no vias needed)*
- **Why hard:** the y≈115 lane crosses 3V3_C's B.Cu via (219,114.5) + tracks, and the diagonal (196.25,111.25)→(202.75,117.75).
- **Fix (GUI):** B.Cu from J2.17 **east at y≈112.5** (the lane between the 3V3_C via's keep-out, top at y=113.7, and everything else is open to x≈265), then south-east into J4.5 (269.5,123.72). 0.25 mm track, no vias.

### 4.9 /PWR_EN — via (256.9, 170.1) (already placed) → J1.7 island (vias (213.75,129) and (219.5,117.75))  *(hardest long haul)*
- **Why hard:** the /E22_AUX B.Cu wall (250.25→259.5, y=168.75) sits right above the escape via; east of it the y≈166–167 lanes are occupied by the new /I2C0_SCL route; south is the U8 pad field; the /+5V_E22 B.Cu vertical (257.5,156→165.75) blocks the north-west.
- **Fix options (GUI):**
  1. **Move the /+5V_E22 vertical 1.5 mm east** (to x≈259, it only feeds J20/U8-area pins — verify with the ratsnest first), opening the y≈165.5 lane west. Then: (256.9,170.1) → east around the /E22_AUX wall's east end (via the same corridor the /I2C0_SCL route uses, y≈170.3–170.5) → north to y≈165.5 → **west all the way** to (219.5,117.75), passing north of the /E22_M1 diagonal (237,136.25)→(259.25,158.5) is NOT needed if you stay at y≈150… you will need to weave — follow the ratsnest.
  2. Or accept a longer path: (256.9,170.1) → east → north-east to (265,150) → west along y≈133 (between /E22_M0 and /UART1_LORA_RX diagonals) → (219.5,117.75).
- Use the ratsnest line (alt+click the net in KiCad) to see where it wants to go.

### 4.10 /I2C0_SCL — U7.22 (243.0, 177.725) → U8.22 (255.0, 164.725)
- **State:** U8.22 is already fed (via (256.4,164.725) from TP8.1). Only U7.22 is orphaned.
- **Why hard:** the corridor between the boards' two chips is crossed by /SENS_EN (B.Cu staircase ending via (251.25,169.75)), /E22_AUX wall (250.25→259.5, y=168.75) + its NE diagonal (262,171.25)→(259.5,168.75), /BUZZER_EN B.Cu (258.25,175→169.75) + via (257.5,167.5), and U8's pad field.
- **Fix (GUI):** U7.22 → via (244.4,177.7) → B.Cu 0.3: (248,176.1) → (252.1,172.1) → (252.1,170.3) → east at y=170.3 — **keep ≥0.65 mm from the /SENS_EN via (251.25,169.75) and its staircase, and ≥0.65 from the /E22_AUX NE diagonal** — pass north of (262,171.25) at y≈170.4–170.5 → down x≈263.3 to y≈167 → the lane at y=167.0 is FREE west of x=258.8 (the /BUZZER_EN via (257.5,167.5) forbids going further west at that y) → 45° to the via (256.4,164.725), which already has the /I2C0_SCL F.Cu stub into U8.22. This was 90 % verified — the scripted attempt failed only on final clearances; with interactive shove it will close.

### 4.11 /I2C0_SCL_CH6 — TP12.1 (293.0, 144.75) → U7.18 (243.0, 180.325)
- **State:** TP12.1's side is fed (F.Cu (293,144.75)→(293,156) etc.). U7.18 orphaned. **First delete the old 34.4 mm F.Cu track (268.675,180.325)→(293,156)** — it was supposed to be replaced by a B.Cu route (it also creates the track_dangling warning).
- **Why hard:** TP12.1's B.Cu pocket exits only south-east (past /E22_GATE diagonal (244,160.5)→(249,155.5) and /UART1_LORA_RX via (258.25,160.25)); U7.18's approach via (245.1,180.325) sits behind the /SENS_EN B.Cu horizontal (194→241.25, y=179.25).
- **Fix (GUI):** TP12.1 → B.Cu north to y≈154 → east to x≈263 (north of the /UART1_LORA_RX via) → south along x≈263–265 (west of /E22_M1, east of /UART1_LORA_TX diagonal (243,161.5)→(227,145.5) — wait, that one is west; the lane x≈263–270 down to y≈170 is inside the /E22_AUX wall area — pass through the same y≈170.3–170.5 corridor as 4.10) → then west along y≈183–185 (south of /SENS_EN horizontal, north of the J-connector escapes) to U7.18's via (245.1,180.325) + F.Cu stub into U7.18. Long but open — follow the ratsnest.

### 4.12 /WDT_WDI — U4.4 (223.7, 149.05) → U8.17 (255.0, 167.975)
- **Why hard:** U8.17's escapes are blocked: west-under-body by /I2C0_SDA F.Cu vertical (253.5,167.75→169.5) + /E22_EN via (251.25,167.75); east by the /BUZZER_EN tail (257.5,167.5)→(255.85,167.36); the inter-pad gaps are 0.23 mm.
- **Fix (GUI):** free the west corridor by **moving /I2C0_SDA's F.Cu vertical (253.5,167.75→169.5) ~1 mm east** (it is U8.23's escape — check it has room; its B.Cu side ends at via (253.25,186) area). Then U8.17 → F.Cu west at y=167.975 to via (251,167.975) (legal: 0.775 mm from the /E22_AUX wall, 0.6 from U8.8's pad — both exact) → B.Cu 0.25 north-west to U4.4's via (225.7,149.05) + F.Cu stub. The middle crosses the /E22_* / UART1_LORA_* diagonals — weave along the ratsnest.

### 4.13 /+5V_SENS — C31.1 (235.0, 166.0) → C33.1 (246.9625, 175.0) and → Q3.3 (176.9375, 168.0)  *(two pairs)*
- **State:** C33.1's island is complete (via (246.95,176) from T34). C31.1 is a THT pad (starts on B.Cu directly).
- **Why hard:** the B.Cu east of C31.1 is a lattice: 3V3_C vertical (233.5,158.75→167.537) + diagonal to via (236.963,171), 3V3_C via (244,171) + diagonal (244,171)→(244.963,167.5), /SENS_EN diagonal, /E22_* diagonals.
- **Fix (GUI):** C31.1 → B.Cu east at y≈164–166 (north of the 3V3_C via (244,171)) → to the T34 via (246.95,176) area — weave south-east past the 3V3_C via (244.963,167.5). For Q3.3: continue west at y≈163–168 (north of the 3V3_C B.Cu bundle (209.25,168)→(213,168) — jog over it at x≈211–215) to a via at (174.9,168) + F.Cu stub into Q3.3 (176.9375,168) (its island reaches F.Cu (147.25,140.98) — that stub is for /LED_DRV2, don't confuse).

---

## 5. Obstacle inventory (the walls you will meet)

Keep this open while routing. All B.Cu unless stated. Net — geometry:

- **/BUZZER_EN**: vertical (245.5, 179→195.25); horizontal (141.75→239, y=201.75); diagonal (132.5,192.5)→(141.75,201.75); (247,177.5)→(255.75,177.5)→(258.25,175)→(258.25,169.75); vias (257.5,167.5) and (258.25,169.75); F.Cu tail (257.5,167.5)→(255.85,167.36) [new]. **This net walls off the whole bottom-left PE pocket — do not move it.**
- **/SENS_EN**: horizontal (194→241.25, y=179.25); staircase (241.25,179.25)→(248.5,172)→(249.5,172)→(251.25,170.25)→via (251.25,169.75); F.Cu (252.25,167.75)→(253.325,166.675)→(255,166.675) and (252.25,168.75)→(252.25,167.75); via (194,179.25).
- **/UART1_LORA_TX**: horizontal (243→257.25, y=161.5); diagonals (243,161.5)→(227,145.5) and (262,166.25)→(257.25,161.5).
- **/UART1_LORA_RX**: diagonals (241,143)→(258.25,160.25) and (217.25,130.25)→(230,143); via (258.25,160.25).
- **/E22_M0**: diagonal (227.5,131.5)→(217.5,121.5).
- **/E22_M1**: diagonals (237,136.25)→(259.25,158.5), (259.25,158.5)→(259.25,160.75)→(263.42,164.92); via (300.75,147.5).
- **/E22_AUX**: diagonal (244.25,166.25)→(229.75,151.75); wall (250.25,168.75)→(259.5,168.75) with diagonals (247.75,166.25)→(250.25,168.75) and (262,171.25)→(259.5,168.75).
- **/E22_GATE**: diagonal (244,160.5)→(249,155.5); (249,155.5)→(249,153.24); via (244,160.5).
- **/E22_EN**: via (246.362,162.3); (250.2,166.7)→(251.25,167.75).
- **/+5V_E22**: vertical (257.5, 156→165.75) — candidate to move east for 4.9.
- **3V3_C lattice**: vertical (233.5,158.75→167.537)→diagonal→via (236.963,171); via (244,171)→(242.75,172.25)→(237.75,172.25); via (244.963,167.5); (222.25,127)→(222.25,128.75)→(224.25,130.75)→(224.25,134.5)→(226,136.25); via (220.5,119.75); (220.5,116.75→125.25); via (219,114.5); (219,115.25)→(220.5,116.75); bundle (209.25,168)→(213,168); (214.65,164.4→166.35); (209.5,151.46→159.25); (165.31,159)→(143.55,159); (177.75,146.75)→(177.75,103.5).
- **/I2C0_SDA**: F.Cu (219.5,130.25)→(217,130.25)→(216.2,131.05); F.Cu vertical (253.5,167.75→169.5) [candidate to move for 4.12]; B.Cu highway (193.625→239.125, y=180.125) [added this session — keep]; B.Cu vertical (295.875,132.625→178.625) + horizontal (290.375→295.625, y=132.375).
- **/I2C0_SDA_CH2**: diagonal (238.6,180.975)→(235.363,184.55).
- **/I2C0_SDA_CH3**: (252.3,185.05)→(248.862,185.05); vias (248.862,185.05), (253.25,186).
- **/I2C0_SDA_CH4**: (246.294,183.7)→(268.45,183.7)→(269.8,185.05); vias (246.294,183.7), (269.862,185.05); track end (274.5,186).
- **/I2C0_SDA_CH6**: B.Cu vertical (294.55,134→156.2) + horizontal (298.5,134)→(294.55,134); F.Cu vertical (294.75,128.25→133.8).
- **/I2C0_SCL_CH2**: F.Cu (234.625,181.625)→(237,181.625) and (237.075,183)→(238.75,183)→(240,184.25).
- **/I2C0_SCL_CH3**: F.Cu (240,184.25)→(244,184.25)→(246.75,187).
- **/I2C0_SCL_CH6**: F.Cu (293,156)→(268.675,180.325) [34.4 mm — DELETE, see 4.11]; F.Cu (293,144.75)→(293,156); F.Cu (294.55,136.75)→(298.75,136.75) + (294.3,137)→(294.3,139.75)→(294.55,136.75)?? — actually (294.3,143.45)→(293,144.75) etc — keep, they feed TP12.1.
- **/I2C0_MUX_SC1**: F.Cu vertical (231.25,161.75→177.25) + diagonal + horizontal to U7.7.
- **/I2C0_MUX_SD0**: via (235,178.25) + track (~227.75→234.25, y=177.5) — candidate to relocate for 4.1.
- **GND**: via (247.0375,167.5) + track (247.79,164.075)→(249,164.725); via (235,177) + track (237,177.075)→(235.075,177.075) (U7.2 escape); vias (237.5375,190), (230.75,193.037).
- **/3V3_SENS_SW**: B.Cu vertical (298.75,141.75→178.8); vias (235.4625,190), (263.7125,191.25), (270,190), (169.13,190.88), (289.55,134), (289.55,136.75).
- **Connector pad rows J11–J25** (THT, pads at y=194.5): their keep-outs nearly touch (2.5 mm pitch, ~2.4 mm keep-out) — B.Cu cannot pass between them anywhere except the 11.8 mm gap between J14.4 (257.5) and J17.1 (271), and small gaps ≥0.9 mm. On F.Cu only 0.3 mm tracks squeeze between adjacent pads (0.8 mm gaps).
- **U8 pad columns** (west x=249, east x=255, 0.65 pitch): F.Cu between the columns (x 249.9–254.1) is FREE except /I2C0_SDA's F.Cu vertical (253.5) and /SENS_EN's F.Cu bits near (252.25,167.75–168.75).

## 6. Verification loop (after every 1–2 routes)

1. `B` in the GUI (or `_auto\refill.py`) — refill zones.
2. DRC: `Inspect → Design Rules Checker → Run` (or the kicad-cli command in section 3).
3. `unconnected_items` count must drop by exactly the number of pairs you closed. If a pair "moved" instead of disappearing, you connected to the wrong island.
4. **Never** finish a session with DRC errors > 0. Current baseline: 0 errors.
5. Watch for new `clearance` errors — the fenced corridors are tight (several are exactly at 0.2 mm).

## 7. Scripted routing reference (`_auto/`)

- `pcbutil.py` — load/save (**crash-safe save: always use it** — a raw `pcbnew.Save()` segfaulted once and truncated the board to 0 bytes), `Copper` snapshot, `check_seg`/`check_via` clearance pre-checks, `add_track`/`add_via`/`set_pad_net`.
- `router.py` — `GridRouter` A* (0.25 mm grid, **pass `netname=`** so same-net copper isn't treated as an obstacle), `simplify_path`, `add_zone`.
- `refill.py` — refill all zones + safe save.
- `inspect_nets.py` — dump every track/via of chosen nets (edit the NETS list).
- `board_dump.py` — full board JSON dump.
- Run everything with: `"C:\Program Files\KiCad\10.0\bin\python.exe" -u _auto\<script>.py`
- **Pitfalls learned:**
  - `b.Remove()` corrupts the board object for the rest of the process — do removals in a dedicated process (load → remove → save → exit), then re-load.
  - The A* solver is a *prover*: when it says "no path", the region really is walled at 0.2 mm clearance — something must move.
  - Route width: 0.3 for I2C/UART/GPIO, 0.5–0.6 for 3V3/5V rails, 1.0 for PE/5V power.
  - After `add_track`, keep the `Copper` snapshot in sync or later checks will false-positive.

## 8. Cosmetic cleanup (optional, from the original 58-task sheet — Part 8)

- 78 × silk-over-copper + 46 × silk-overlap (mostly around U7/U8 and the connector field): move/hide reference designators (`E` → drag text, or footprint properties → hide reference).
- 2 × text-thickness on the `5v +` / `5v -` labels: set stroke font, 0.15 mm.
- 1 × lib-footprint-mismatch on **Q9**: right-click → *Update Footprint from Library*.
- 6 track-dangling / 5 via-dangling warnings: all pre-existing zone-stitching vias and small stubs — the via-dangling ones are GND/3V3_SENS_SW stitching vias that connect to planes; safe to ignore (or delete individual ones after checking they touch no plane).

## 9. Fabrication (final step — Part 9 of the original sheet)

1. Refill zones (`B`), run DRC → must be **0 errors** and **0 unconnected**.
2. `File → Fabrication Outputs → Gerbers` (F.Cu, B.Cu, In1.Cu, In2.Cu + mask + silk + edge), `NC Drill` (excellon, through), and a PDF plot for reference.
3. Board stackup to give the fab: **4 layers, 1.6 mm, min track/clearance 0.2 mm, min via 0.6/0.3 mm (design uses 0.8/0.45), 1 oz copper**.
4. Order notes: ENIG or HASL, solder mask both sides, e-test.

## 10. Quick reference — what the ratsnest says right now

Run the DRC JSON and look at `unconnected_items` — as of export:
1. 3V3_C ESD1.5 ↔ (222.25,128.75) fragment — §4.2
2. 3V3_C (244.96,165.99) stub ↔ U8.24 — §4.3
3. 3V3_C J4.3 ↔ (225,126.25) fragment — §4.4
4. PE ESD19.2 tail ↔ ESD18.2 tail — §4.5
5. PE J19.1 ↔ ESD18.2 tail — §4.5
6. /LED_DRV1 R51.1 ↔ U8.4 — §4.6
7. /UART2_MOD_TX J2.17 ↔ J4.5 — §4.8
8. /PWR_EN (256.9,170.1) ↔ J1.7 island — §4.9
9. /I2C0_SCL U7.22 ↔ (256.4,164.725) — §4.10
10. /+5V_SENS C31.1 ↔ Q3.3 — §4.13
11. /+5V_SENS C33.1 ↔ C31.1 — §4.13
12. /I2C0_SCL_CH6 U7.18 ↔ TP12.1 side — §4.11
13. /WDT_WDI U4.4 ↔ U8.17 — §4.12
14. /I2C0_MUX_SC0 R32.1 ↔ U7.5 — §4.1
15. /LED_DRV2 U8.5 via ↔ R52.1 — §4.7

**Suggested order:** 4.5 → 4.3 → 4.10 → 4.4 → 4.2 → 4.7 → 4.6 → 4.13 → 4.8 → 4.11 → 4.9 → 4.12 → 4.1
(easiest and net-critical first; 4.9 and 4.12 last — they need existing copper moved).
