# -*- coding: utf-8 -*-
"""Shared helpers for board editing with KiCad 10 pcbnew."""
import sys, math
sys.path.insert(0, r'C:\Program Files\KiCad\10.0\bin')
import pcbnew

BOARD = 'MoriShield_Carrier.kicad_pcb'
CLEAR = 0.2  # default net class clearance (mm)

def load(path=BOARD):
    b = pcbnew.LoadBoard(path)
    if b is None:
        raise RuntimeError('LoadBoard failed for ' + path)
    return b

def save(b, path=BOARD):
    """Crash-safe save: write a temp copy, verify it parses, then atomically replace."""
    import shutil, tempfile, os
    d = os.path.dirname(os.path.abspath(path)) or '.'
    fd, tmp = tempfile.mkstemp(prefix='_save_', suffix='.kicad_pcb', dir=d)
    os.close(fd)
    ok = False
    try:
        b.Save(tmp)
        if os.path.getsize(tmp) < 100000:
            raise RuntimeError('saved file suspiciously small: ' + str(os.path.getsize(tmp)))
        chk = pcbnew.LoadBoard(tmp)
        if chk is None:
            raise RuntimeError('temp save failed to re-parse')
        del chk
        shutil.move(tmp, path)
        ok = True
    finally:
        if not ok and os.path.exists(tmp):
            os.remove(tmp)
    return ok

def mm(v):
    return pcbnew.FromMM(v)

def net(b, name):
    n = b.FindNet(name)
    if n is None:
        raise RuntimeError('net not found: ' + name)
    return n

def layer_by_name(b, name):
    for l in pcbnew.LAYER_ID.values() if hasattr(pcbnew.LAYER_ID, 'values') else []:
        pass
    return pcbnew.LayerEnum(name) if hasattr(pcbnew, 'LayerEnum') else _lnum(b, name)

def _lnum(b, name):
    for i in range(pcbnew.PCB_LAYER_ID_COUNT):
        if b.GetLayerName(i) == name:
            return i
    raise RuntimeError('layer not found: ' + name)

F = 'F.Cu'
B = 'B.Cu'

# ---------------- geometry helpers (mm space) ----------------
def _orient(a, b, c):
    v = (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])
    if v > 1e-12: return 1
    if v < -1e-12: return -1
    return 0

def _on_seg(a, b, c):
    return (min(a[0], b[0]) - 1e-12 <= c[0] <= max(a[0], b[0]) + 1e-12 and
            min(a[1], b[1]) - 1e-12 <= c[1] <= max(a[1], b[1]) + 1e-12)

def segs_intersect(p1, p2, p3, p4):
    d1 = _orient(p3, p4, p1)
    d2 = _orient(p3, p4, p2)
    d3 = _orient(p1, p2, p3)
    d4 = _orient(p1, p2, p4)
    if ((d1 > 0 and d2 < 0) or (d1 < 0 and d2 > 0)) and ((d3 > 0 and d4 < 0) or (d3 < 0 and d4 > 0)):
        return True
    if d1 == 0 and _on_seg(p3, p4, p1): return True
    if d2 == 0 and _on_seg(p3, p4, p2): return True
    if d3 == 0 and _on_seg(p1, p2, p3): return True
    if d4 == 0 and _on_seg(p1, p2, p4): return True
    return False

def seg_seg_dist(p1, p2, p3, p4):
    """Min distance between segments (x1,y1,x2,y2) tuples."""
    if segs_intersect(p1, p2, p3, p4):
        return 0.0
    def d_pt_seg(px, py, x1, y1, x2, y2):
        dx, dy = x2-x1, y2-y1
        L2 = dx*dx + dy*dy
        if L2 == 0:
            return math.hypot(px-x1, py-y1)
        t = max(0, min(1, ((px-x1)*dx + (py-y1)*dy)/L2))
        return math.hypot(px-(x1+t*dx), py-(y1+t*dy))
    d1 = d_pt_seg(*p1, *p3, *p4)
    d2 = d_pt_seg(*p2, *p3, *p4)
    d3 = d_pt_seg(*p3, *p1, *p2)
    d4 = d_pt_seg(*p4, *p1, *p2)
    return min(d1, d2, d3, d4)

def pt_seg_dist(px, py, x1, y1, x2, y2):
    dx, dy = x2-x1, y2-y1
    L2 = dx*dx + dy*dy
    if L2 == 0:
        return math.hypot(px-x1, py-y1)
    t = max(0, min(1, ((px-x1)*dx + (py-y1)*dy)/L2))
    return math.hypot(px-(x1+t*dx), py-(y1+t*dy))

def seg_aabb_dist(x1, y1, x2, y2, bx0, by0, bx1, by1):
    """Distance between segment and axis-aligned box (0 if intersecting)."""
    corners = [(bx0, by0), (bx1, by0), (bx1, by1), (bx0, by1)]
    # if bounding boxes overlap, do proper intersection tests
    if not (max(x1,x2) < bx0 or min(x1,x2) > bx1 or max(y1,y2) < by0 or min(y1,y2) > by1):
        if (bx0 <= x1 <= bx1 and by0 <= y1 <= by1) or (bx0 <= x2 <= bx1 and by0 <= y2 <= by1):
            return 0.0
        def seg_int(p1, p2, p3, p4):
            def ccw(a, b, c):
                return (c[1]-a[1])*(b[0]-a[0]) - (b[1]-a[1])*(c[0]-a[0])
            d1 = ccw(p3, p4, p1); d2 = ccw(p3, p4, p2)
            d3 = ccw(p1, p2, p3); d4 = ccw(p1, p2, p4)
            return ((d1>0)!=(d2>0)) and ((d3>0)!=(d4>0))
        for k in range(4):
            if seg_int((x1,y1),(x2,y2), corners[k], corners[(k+1)%4]):
                return 0.0
        # no intersection but boxes overlap: nearest corner of box to segment
        return min(pt_seg_dist(cx, cy, x1, y1, x2, y2) for (cx, cy) in corners)
    # segment fully outside bbox region
    d = 1e9
    for (cx, cy) in corners:
        d = min(d, pt_seg_dist(cx, cy, x1, y1, x2, y2))
    for (px, py) in ((x1,y1),(x2,y2)):
        if bx0 <= px <= bx1:
            if py > by1:
                d = min(d, py - by1)
            elif py < by0:
                d = min(d, by0 - py)
            else:
                d = 0.0
        elif by0 <= py <= by1:
            if px > bx1:
                d = min(d, px - bx1)
            elif px < bx0:
                d = min(d, bx0 - px)
            else:
                d = 0.0
        else:
            d = min(d, math.hypot(max(bx0-px,0,px-bx1), max(by0-py,0,py-by1)))
    return d

# ---------------- copper inventory ----------------
class Copper:
    """Snapshot of existing copper for clearance checks. All coords in mm."""
    def __init__(self, b):
        self.b = b
        self.segs = []   # (layer, x1,y1,x2,y2, width, net)
        self.vias = []   # (x, y, dia, net)
        self.pads = []   # (x, y, sx, sy, rot, shape, net, layers(set of cu layer names), drill)
        for t in b.GetTracks():
            nname = t.GetNetname()
            if t.GetClass() == 'PCB_VIA':
                pos = t.GetPosition()
                self.vias.append((pos.x/1e6, pos.y/1e6, t.GetWidth(0)/1e6 if hasattr(t,'GetWidth') else 0.6, nname))
            else:
                s, e = t.GetStart(), t.GetEnd()
                self.segs.append((b.GetLayerName(t.GetLayer()), s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6,
                                  t.GetWidth()/1e6, nname))
        for f in b.GetFootprints():
            for p in f.Pads():
                pos = p.GetPosition()
                sz = p.GetSize()
                dr = p.GetDrillSize().x/1e6
                layers = set()
                if p.IsOnLayer(pcbnew.F_Cu): layers.add('F.Cu')
                if p.IsOnLayer(pcbnew.B_Cu): layers.add('B.Cu')
                # THT pads are on both
                if p.GetAttribute() in (pcbnew.PAD_ATTRIB_PTH, pcbnew.PAD_ATTRIB_NPTH):
                    layers = {'F.Cu', 'B.Cu'}
                self.pads.append(dict(x=pos.x/1e6, y=pos.y/1e6,
                                      sx=sz.x/1e6, sy=sz.y/1e6,
                                      rot=p.GetOrientationDegrees(),
                                      shape=str(p.GetShape()), net=p.GetNetname(),
                                      layers=layers, drill=dr,
                                      ref=f.GetReference(), num=p.GetNumber()))

    def check_seg(self, layer, x1, y1, x2, y2, w, netname, clear=CLEAR, ignore_refs=()):
        """Return list of conflict strings for a proposed track segment."""
        bad = []
        half = w/2
        for (L, a1, b1, a2, b2, tw, tn) in self.segs:
            if L != layer: continue
            if tn == netname: continue
            d = seg_seg_dist((x1,y1),(x2,y2),(a1,b1),(a2,b2))
            need = half + tw/2 + clear
            if d < need:
                bad.append(f'seg vs track net={tn} d={d:.3f}<{need:.3f} @{(a1,b1,a2,b2)}')
        for (vx, vy, dia, tn) in self.vias:
            if tn == netname: continue
            d = pt_seg_dist(vx, vy, x1, y1, x2, y2)
            need = half + dia/2 + clear
            if d < need:
                bad.append(f'seg vs via net={tn} d={d:.3f}<{need:.3f} @{(vx,vy)}')
        for p in self.pads:
            if p['net'] == netname: continue
            if layer not in p['layers']: continue
            if p['ref'] in ignore_refs: continue
            # pad bbox (rot 0/90 handled by swap); full bbox = conservative model
            sx, sy = p['sx'], p['sy']
            if abs(p['rot'] % 180) == 90:
                sx, sy = sy, sx
            bx0, by0, bx1, by1 = p['x']-sx/2, p['y']-sy/2, p['x']+sx/2, p['y']+sy/2
            d = seg_aabb_dist(x1, y1, x2, y2, bx0, by0, bx1, by1)
            need = half + clear
            if d < need:
                bad.append(f"seg vs pad {p['ref']}.{p['num']} net={p['net']} d={d:.3f}<{need:.3f}")
        return bad

    def check_via(self, x, y, dia, netname, clear=CLEAR, ignore_refs=()):
        bad = []
        r = dia/2
        for (L, a1, b1, a2, b2, tw, tn) in self.segs:
            if tn == netname: continue
            d = pt_seg_dist(x, y, a1, b1, a2, b2)
            need = r + tw/2 + clear
            if d < need:
                bad.append(f'via vs track net={tn} d={d:.3f}<{need:.3f} @{(a1,b1,a2,b2)}')
        for (vx, vy, vdia, tn) in self.vias:
            if tn == netname: continue
            d = math.hypot(vx-x, vy-y)
            need = r + vdia/2 + clear
            if d < need:
                bad.append(f'via vs via net={tn} d={d:.3f}<{need:.3f} @{(vx,vy)}')
        for p in self.pads:
            if p['net'] == netname: continue
            if p['drill'] > 0:
                lays = {'F.Cu', 'B.Cu'}
            else:
                lays = p['layers']
            if not ({'F.Cu','B.Cu'} & lays): continue
            if p['ref'] in ignore_refs: continue
            sx, sy = p['sx'], p['sy']
            if abs(p['rot'] % 180) == 90:
                sx, sy = sy, sx
            bx0, by0, bx1, by1 = p['x']-sx/2, p['y']-sy/2, p['x']+sx/2, p['y']+sy/2
            cx = max(bx0, min(x, bx1)); cy = max(by0, min(y, by1))
            d = math.hypot(x-cx, y-cy)
            need = r + clear
            if d < need:
                bad.append(f"via vs pad {p['ref']}.{p['num']} net={p['net']} d={d:.3f}<{need:.3f}")
        return bad

# ---------------- builders ----------------
def add_track(b, netname, layer, pts, width, layer_num=None):
    """Add tracks through a polyline. pts: [(x,y)...] mm. Returns list of new PCB_TRACKs."""
    ln = _lnum(b, layer)
    n = net(b, netname)
    out = []
    for k in range(len(pts)-1):
        (x1, y1), (x2, y2) = pts[k], pts[k+1]
        if abs(x1-x2) < 1e-9 and abs(y1-y2) < 1e-9:
            continue
        t = pcbnew.PCB_TRACK(b)
        t.SetStart(pcbnew.VECTOR2I(mm(x1), mm(y1)))
        t.SetEnd(pcbnew.VECTOR2I(mm(x2), mm(y2)))
        t.SetWidth(mm(width))
        t.SetLayer(ln)
        t.SetNetCode(n.GetNetCode())
        b.Add(t)
        out.append(t)
    return out

def add_via(b, netname, x, y, dia, drill):
    n = net(b, netname)
    v = pcbnew.PCB_VIA(b)
    v.SetPosition(pcbnew.VECTOR2I(mm(x), mm(y)))
    v.SetWidth(mm(dia))
    v.SetDrill(mm(drill))
    v.SetViaType(pcbnew.VIATYPE_THROUGH)
    v.SetLayerPair(pcbnew.F_Cu, pcbnew.B_Cu)
    v.SetNetCode(n.GetNetCode())
    b.Add(v)
    return v

def set_pad_net(b, ref, num, netname):
    for f in b.GetFootprints():
        if f.GetReference() == ref:
            for p in f.Pads():
                if p.GetNumber() == num:
                    p.SetNetCode(net(b, netname).GetNetCode())
                    return True
    raise RuntimeError(f'pad {ref}.{num} not found')
