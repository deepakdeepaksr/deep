# -*- coding: utf-8 -*-
"""Refill all zones safely (separate process, safe save)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcbutil import *

b = load()
print('zones:', [(z.GetNetname(), b.GetLayerName(z.GetLayer())) for z in b.Zones()], flush=True)
filler = pcbnew.ZONE_FILLER(b)
filler.Fill(b.Zones())
print('fill done', flush=True)
save(b)
print('saved', flush=True)
