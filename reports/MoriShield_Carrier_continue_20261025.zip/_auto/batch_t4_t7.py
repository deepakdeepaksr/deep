# -*- coding: utf-8 -*-
"""T4/T5: set U8.1 + D6.1 to GND, route U8.1-U8.2 jumper.
T6/T7: 3V3_SENS_SW zone rect + vias at R47.2/R48.2."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcbutil import *

b = load()
c = Copper(b)

# --- T4: net assignments (schematic already fixed) ---
set_pad_net(b, 'U8', '1', 'GND')
print('U8.1 -> GND')
set_pad_net(b, 'D6', '1', 'GND')
print('D6.1 -> GND')

# --- T5a: U8.1-U8.2 jumper, 0.3mm F.Cu ---
bad = c.check_seg(F, 249.0, 163.425, 249.0, 164.075, 0.3, 'GND')
print('jumper conflicts:', len(bad), bad[:3])
if not bad:
    add_track(b, 'GND', F, [(249.0, 163.425), (249.0, 164.075)], 0.3)
    print('jumper added')

# --- T6: 3V3_SENS_SW island extension (In2.Cu rect) ---
poly = pcbnew.SHAPE_POLY_SET()
poly.NewOutline()
for (x, y) in ((286.0, 130.0), (300.0, 130.0), (300.0, 200.0), (286.0, 200.0)):
    poly.Append(mm(x), mm(y))
z = pcbnew.ZONE(b)
z.SetLayer(pcbnew.In2_Cu)
z.SetNet(net(b, '/3V3_SENS_SW'))
z.SetAssignedPriority(2)          # same as the existing island -> wins over +5V plane
z.SetLocalClearance(mm(0.25))
z.SetMinThickness(mm(0.2))
z.SetOutline(poly)
z.SetIsFilled(False)
b.Add(z)
print('3V3_SENS_SW rect zone added (In2.Cu)')

# --- T7: vias at R47.2 / R48.2 ---
for (ref, num, px, py) in (('R47', '2', 291.45, 134.0), ('R48', '2', 291.45, 136.75)):
    done = False
    for (dx, dy) in ((1.9, 0), (-1.9, 0), (1.9, -1.0), (-1.9, -1.0), (1.9, 1.0), (0, 2.2), (0, -2.2)):
        vx, vy = round((px+dx)*20)/20, round((py+dy)*20)/20
        probs = [p for p in c.check_seg(F, px, py, vx, vy, 0.6, '/3V3_SENS_SW')]
        probs += [p for p in c.check_via(vx, vy, 0.8, '/3V3_SENS_SW')]
        if probs:
            print(f'{ref}.{num} via ({vx},{vy}):', probs[:2])
            continue
        add_via(b, '/3V3_SENS_SW', vx, vy, 0.8, 0.45)
        add_track(b, '/3V3_SENS_SW', F, [(px, py), (vx, vy)], 0.6)
        print(f'{ref}.{num}: via ({vx},{vy}) + stub OK')
        done = True
        break
    if not done:
        print(f'!! {ref}.{num}: no via spot')

save(b)
print('saved')
