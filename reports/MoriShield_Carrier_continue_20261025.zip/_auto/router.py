# -*- coding: utf-8 -*-
"""A* grid router on one copper layer + zone builder."""
import sys, os, math, heapq
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcbutil import *
from pcbutil import _lnum

GRID = 0.25

class GridRouter:
    def __init__(self, c, layer, my_width, x0, y0, x1, y1, clear=0.2, netname=None):
        """c: Copper; layer: 'B.Cu'/'F.Cu'; board area in mm.
        netname: obstacles of this net are ignored (same-net copper is routable)."""
        self.c = c
        self.layer = layer
        self.w = my_width
        self.clear = clear
        self.netname = netname
        self.x0, self.y0 = x0, y0
        self.nx = int(round((x1-x0)/GRID)) + 1
        self.ny = int(round((y1-y0)/GRID)) + 1
        self.blocked = [[False]*self.ny for _ in range(self.nx)]
        self._build()

    def _block_seg(self, ax, ay, bx, by, half, clear):
        """Block cells within (half+clear) of segment (ax,ay)-(bx,by)."""
        r = half + clear
        gx0 = max(0, int((min(ax,bx)-r-self.x0)/GRID) - 1)
        gx1 = min(self.nx-1, int((max(ax,bx)+r-self.x0)/GRID) + 1)
        gy0 = max(0, int((min(ay,by)-r-self.y0)/GRID) - 1)
        gy1 = min(self.ny-1, int((max(ay,by)+r-self.y0)/GRID) + 1)
        for ix in range(gx0, gx1+1):
            for iy in range(gy0, gy1+1):
                if self.blocked[ix][iy]:
                    continue
                cx = self.x0 + ix*GRID
                cy = self.y0 + iy*GRID
                if pt_seg_dist(cx, cy, ax, ay, bx, by) < r:
                    self.blocked[ix][iy] = True

    def _build(self):
        c = self.c
        r_track = self.w/2 + self.clear
        for (L, a1, b1, a2, b2, tw, tn) in c.segs:
            if L != self.layer: continue
            if self.netname is not None and tn == self.netname: continue
            self._block_seg(a1, b1, a2, b2, tw/2, r_track)
        for (vx, vy, dia, tn) in c.vias:
            if self.netname is not None and tn == self.netname: continue
            self._block_pt(vx, vy, dia/2, r_track)
        for p in c.pads:
            if self.netname is not None and p['net'] == self.netname: continue
            lays = {'F.Cu','B.Cu'} if p['drill'] > 0 else p['layers']
            if self.layer not in lays: continue
            sx, sy = p['sx'], p['sy']
            if abs(p['rot'] % 180) == 90:
                sx, sy = sy, sx
            # block 4 edges of the pad bbox
            bx0, by0, bx1, by1 = p['x']-sx/2, p['y']-sy/2, p['x']+sx/2, p['y']+sy/2
            self._block_seg(bx0, by0, bx1, by0, 0, r_track)
            self._block_seg(bx1, by0, bx1, by1, 0, r_track)
            self._block_seg(bx1, by1, bx0, by1, 0, r_track)
            self._block_seg(bx0, by1, bx0, by0, 0, r_track)

    def _block_pt(self, px, py, half, clear):
        r = half + clear
        gx0 = max(0, int((px-r-self.x0)/GRID)-1); gx1 = min(self.nx-1, int((px+r-self.x0)/GRID)+2)
        gy0 = max(0, int((py-r-self.y0)/GRID)-1); gy1 = min(self.ny-1, int((py+r-self.y0)/GRID)+2)
        for ix in range(gx0, gx1+1):
            for iy in range(gy0, gy1+1):
                if self.blocked[ix][iy]:
                    continue
                cx = self.x0 + ix*GRID
                cy = self.y0 + iy*GRID
                if math.hypot(cx-px, cy-py) < r:
                    self.blocked[ix][iy] = True

    def free(self, gx, gy):
        return 0 <= gx < self.nx and 0 <= gy < self.ny and not self.blocked[gx][gy]

    def to_grid(self, x, y):
        return (int(round((x-self.x0)/GRID)), int(round((y-self.y0)/GRID)))

    def to_mm(self, gx, gy):
        return (self.x0 + gx*GRID, self.y0 + gy*GRID)

    def astar(self, start, goal_test, turn_penalty=0.3, max_expand=2_000_000):
        """start (gx,gy) free cell; goal_test(gx,gy)->bool. Returns list of (x,y) mm or None."""
        if not self.free(*start):
            # nudge to nearest free cell within 2mm
            start = self._nearest_free(start)
            if start is None:
                return None
        openh = [(0.0, 0.0, start, None)]
        came = {start: (None, None)}
        gscore = {start: 0.0}
        expand = 0
        while openh:
            f, g, node, parent = heapq.heappop(openh)
            if node in came and came[node][0] is not None and g > gscore.get(node, 1e18) + 1e-9:
                continue
            expand += 1
            if expand > max_expand:
                return None
            if goal_test(*node):
                # reconstruct
                path = [node]
                while came[node][0] is not None:
                    node = came[node][0]
                    path.append(node)
                path.reverse()
                return [self.to_mm(*p) for p in path]
            px, py = node
            pdir = came[node][1]
            for (dx, dy) in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
                nx_, ny_ = px+dx, py+dy
                if not self.free(nx_, ny_):
                    continue
                if dx and dy:
                    if not (self.free(px+dx, py) and self.free(px, py+dy)):
                        continue  # no corner cutting
                step = math.hypot(dx, dy)
                dirv = (dx, dy)
                turn = 0.0 if pdir is None or pdir == dirv else turn_penalty
                ng = g + step + turn
                if ng < gscore.get((nx_, ny_), 1e18) - 1e-9:
                    gscore[(nx_, ny_)] = ng
                    came[(nx_, ny_)] = (node, dirv)
                    heapq.heappush(openh, (ng, ng, (nx_, ny_), node))
        return None

    def _nearest_free(self, start, rad=12):
        sx, sy = start
        for r in range(1, rad):
            for dx in range(-r, r+1):
                for dy in (-r, r):
                    if self.free(sx+dx, sy+dy):
                        return (sx+dx, sy+dy)
            for dy in range(-r+1, r):
                for dx in (-r, r):
                    if self.free(sx+dx, sy+dy):
                        return (sx+dx, sy+dy)
        return None

def simplify_path(path):
    """Merge collinear/45° grid steps into polyline points."""
    if not path:
        return path
    out = [path[0]]
    for k in range(1, len(path)-1):
        ax, ay = out[-1]
        bx, by = path[k]
        cx, cy = path[k+1]
        d1 = (bx-ax, by-ay)
        d2 = (cx-bx, cy-by)
        # normalize directions to compare
        n1 = (d1[0]/(abs(d1[0]) or 1), d1[1]/(abs(d1[1]) or 1)) if d1 != (0,0) else d2
        if abs(d1[0]) > 1e-9: n1x = d1[0]/abs(d1[0])
        else: n1x = 0
        if abs(d1[1]) > 1e-9: n1y = d1[1]/abs(d1[1])
        else: n1y = 0
        if abs(d2[0]) > 1e-9: n2x = d2[0]/abs(d2[0])
        else: n2x = 0
        if abs(d2[1]) > 1e-9: n2y = d2[1]/abs(d2[1])
        else: n2y = 0
        # slope compare (dx==0 -> vertical, dy==0 -> horizontal, else ratio)
        def slope(d):
            if d[0] == 0: return 'V'
            if d[1] == 0: return 'H'
            return d[1]/d[0]
        s1 = (n1x, n1y)
        s2 = (n2x, n2y)
        if s1 != s2:
            out.append(path[k])
    out.append(path[-1])
    return out

def add_zone(b, netname, layer, outline_pts, clearance=0.25, priority=0, min_thick=0.2):
    """outline_pts: [(x,y)] mm polygon."""
    poly = pcbnew.SHAPE_POLY_SET()
    poly.NewOutline()
    for (x, y) in outline_pts:
        poly.Append(mm(x), mm(y))
    z = pcbnew.ZONE(b)
    z.SetLayer(_lnum(b, layer))
    z.SetNet(net(b, netname))
    z.SetAssignedPriority(priority)
    z.SetLocalClearance(mm(clearance))
    z.SetMinThickness(mm(min_thick))
    z.SetOutline(poly)
    z.SetIsFilled(False)
    b.Add(z)
    return z

def refill_zones(b):
    filler = pcbnew.ZONE_FILLER(b)
    filler.Fill(b.Zones())
    b.Save(b.GetFileName())
