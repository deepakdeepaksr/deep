# -*- coding: utf-8 -*-
"""Dump board state: nets, netclasses, footprints/pads, tracks, vias, zones."""
import sys, json
sys.path.insert(0, r'C:\Program Files\KiCad\10.0\bin')
import pcbnew

B = sys.argv[1] if len(sys.argv) > 1 else 'MoriShield_Carrier.kicad_pcb'
b = pcbnew.LoadBoard(B)
print('board:', B, ' layers:', b.GetCopperLayerCount(), ' nets:', b.GetNetCount())

out = {}

# net table
nets = {}
for n in b.GetNetsByNetcode().values():
    if n.GetNetCode() >= 0:
        nets[n.GetNetCode()] = n.GetNetname()
out['nets'] = nets

# net classes
nc = {}
try:
    ds = b.GetDesignSettings()
    for cls in ds.GetNetClasses():
        name = cls.GetName()
        nc[name] = dict(clearance=cls.GetClearance()/1e6, track=cls.GetTrackWidth()/1e6,
                        viaDia=cls.GetViaDiameter()/1e6, viaDrill=cls.GetViaDrill()/1e6,
                        uviaDia=cls.GetuViaDiameter()/1e6,
                        nets=sorted(cls.GetNetNames()))
except Exception as ex:
    print('netclass err', ex)
out['netclasses'] = nc

# design rule minima
try:
    ds = b.GetDesignSettings()
    out['rules'] = dict(mclear=ds.GetBiggestClearanceValue()/1e6,
                        mtrack=ds.GetTrackMinWidth()/1e6,
                        mviamin=ds.GetViaMinSize()/1e6, mviadrill=ds.GetViaMinDrill()/1e6,
                        mh2h=ds.GetMinHoleToHole()/1e6)
except Exception as ex:
    print('rules err', ex)

# footprints & pads
fps = []
for f in b.GetFootprints():
    pads = []
    for p in f.Pads():
        pads.append(dict(num=p.GetNumber(),
                         x=p.GetPosition().x/1e6, y=p.GetPosition().y/1e6,
                         sx=p.GetSize().x/1e6, sy=p.GetSize().y/1e6,
                         net=p.GetNetname(), netcode=p.GetNetCode(),
                         tht=p.IsTHT() if hasattr(p,'IsTHT') else None,
                         shape=str(p.GetShape()),
                         drill=(p.GetDrillSize().x/1e6) if p.GetDrillSize().x else 0))
    fps.append(dict(ref=f.GetReference(), x=f.GetPosition().x/1e6, y=f.GetPosition().y/1e6,
                    layer=b.GetLayerName(f.GetLayer()), pads=pads))
out['footprints'] = fps

# tracks/vias per layer summary
tr = {'F.Cu':0,'B.Cu':0,'In1.Cu':0,'In2.Cu':0}
segs = []
for t in b.GetTracks():
    if t.GetClass() == 'PCB_VIA':
        segs.append(dict(kind='via', x=t.GetPosition().x/1e6, y=t.GetPosition().y/1e6,
                         dia=t.GetWidth()/1e6, drill=t.GetDrillValue()/1e6, net=t.GetNetname()))
    else:
        ln = b.GetLayerName(t.GetLayer())
        tr[ln] = tr.get(ln,0)+1
        segs.append(dict(kind='seg', layer=ln, x1=t.GetStart().x/1e6, y1=t.GetStart().y/1e6,
                         x2=t.GetEnd().x/1e6, y2=t.GetEnd().y/1e6, w=t.GetWidth()/1e6,
                         net=t.GetNetname()))
out['tracks'] = segs
out['trackcount'] = tr

# zones
zs = []
for z in b.Zones():
    zs.append(dict(net=z.GetNetname(), layer=b.GetLayerName(z.GetLayer()),
                   prio=z.GetAssignedPriority(),
                   bbox=[v/1e6 for v in (z.GetBoundingBox().GetLeft(), z.GetBoundingBox().GetTop(),
                                          z.GetBoundingBox().GetRight(), z.GetBoundingBox().GetBottom())]))
out['zones'] = zs

json.dump(out, open('_auto/board_dump.json','w'), indent=1)
print('footprints:', len(fps), ' tracks/vias:', len(segs), ' zones:', len(zs))
print('tracks per layer:', tr)
