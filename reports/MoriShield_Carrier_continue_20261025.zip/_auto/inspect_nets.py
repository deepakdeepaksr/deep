# -*- coding: utf-8 -*-
"""Inspect existing copper of nets to route + dangling items."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcbutil import *

b = load()
NETS = ['3V3_C', '/+5V_SENS', '/I2C0_SCL', '/I2C0_SCL_CH0', '/I2C0_SCL_CH5',
        '/I2C0_SCL_CH6', '/I2C0_SDA_CH3', '/I2C0_SDA_CH4', '/I2C_SW_RST',
        '/I2C0_MUX_SC0', '/WDT_WDI', '/LED_DRV1', '/LED_DRV2', '/PWR_EN',
        '/UART2_MOD_TX', '/BUZZER_EN', '/EVENT_BTN']
for n in NETS:
    segs = [(b.GetLayerName(t.GetLayer()), round(t.GetStart().x/1e6,3), round(t.GetStart().y/1e6,3),
             round(t.GetEnd().x/1e6,3), round(t.GetEnd().y/1e6,3), round(t.GetWidth()/1e6,2))
            for t in b.GetTracks() if t.GetClass()=='PCB_TRACK' and t.GetNetname()==n]
    vias = [(round(t.GetPosition().x/1e6,3), round(t.GetPosition().y/1e6,3), round(t.GetWidth(0)/1e6,2))
            for t in b.GetTracks() if t.GetClass()=='PCB_VIA' and t.GetNetname()==n]
    print(f'=== {n}: {len(segs)} segs, {len(vias)} vias')
    for s in segs: print('   ', s)
    for v in vias: print('    VIA', v)
