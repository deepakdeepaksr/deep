# -*- coding: utf-8 -*-
"""Cleanup: T44 track, dangling vias. Run alone (Remove corrupts in-process)."""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pcbutil import *

b = load()

# T44: the 3V3_C F.Cu track causing the clearance error near U8.1
# (248.034,162.915)->(244.963,165.987) - superseded; delete it.
removed = []
for t in list(b.GetTracks()):
    if t.GetClass() != 'PCB_TRACK':
        continue
    if t.GetNetname() != '3V3_C' or b.GetLayerName(t.GetLayer()) != 'F.Cu':
        continue
    s, e = t.GetStart(), t.GetEnd()
    sx, sy, ex, ey = s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6
    if (abs(sx-248.034) < 0.01 and abs(sy-162.915) < 0.01) or \
       (abs(ex-248.034) < 0.01 and abs(ey-162.915) < 0.01):
        b.Remove(t)
        removed.append(('T44track', round(sx,3), round(sy,3)))

# dangling vias: report all vias with no touching track/pad on either layer
def via_connected(v):
    vx, vy = v.GetPosition().x/1e6, v.GetPosition().y/1e6
    net = v.GetNetname()
    r = v.GetWidth(0)/1e6/2
    for t in b.GetTracks():
        if t is v or t.GetNetname() != net:
            continue
        if t.GetClass() == 'PCB_VIA':
            d = math.hypot(t.GetPosition().x/1e6-vx, t.GetPosition().y/1e6-vy)
            if d < (r + t.GetWidth(0)/1e6/2) * 0.9:
                return True
        else:
            s, e = t.GetStart(), t.GetEnd()
            if pt_seg_dist(vx, vy, s.x/1e6, s.y/1e6, e.x/1e6, e.y/1e6) < r + t.GetWidth()/1e6/2 - 0.01:
                return True
    return False

import math
dangling = []
for t in list(b.GetTracks()):
    if t.GetClass() == 'PCB_VIA':
        if not via_connected(t):
            dangling.append(t)

print('dangling vias found:', len(dangling))
for v in dangling:
    p = v.GetPosition()
    print(f'  ({p.x/1e6:.3f},{p.y/1e6:.3f}) net={v.GetNetname()}')

# delete only the known-purposeless ones (net has other copper; via floats)
for v in dangling:
    p = v.GetPosition()
    x, y = p.x/1e6, p.y/1e6
    net = v.GetNetname()
    # keep PE vias (they sit in the pour); delete others that float
    if net == 'PE':
        continue
    b.Remove(v)
    removed.append(('via', round(x,3), round(y,3), net))

print('removed:', removed)
save(b)
print('saved')
